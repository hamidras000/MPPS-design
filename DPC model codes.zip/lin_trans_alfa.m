function[alfa]=lin_trans_alfa(y,WC_tot,A,y_inter)
% Input: y, array of distans for low side pipe 
% diamter of pipe [m]
% WC_tot totalt water cut
% A, array of Area 
% Output. Water content alfa(y) as a function of position y, distance from
% y=0, lower pipe
d=y(end);
if y>d
    disp('postiton outside of pipe, y larger then d, diameter of pipe')
    return
end

error=1;

delta=10e-5;
a=y(1);
b=y(end);
h=rand;
d_inter=y_inter;

%sub_alfa=lin_trans_disp(y,h,d_inter);
f=@(h) WC_tot- (sum(A.*(lin_trans_disp(y,h,d_inter)))./sum(A));


[c,err,yc]=bisect(f,a,b,delta);

alfa=lin_trans_disp(y,c,d_inter);


return