% Sigurd Harstad
% 16.4.2020
% Posjekt
% Three layer model, By Heiner Schumann

close all
clear all
clc

%% Konstanter
rho_w = 1000; %[kg/m3] Tetthet vann
rho_o = 600; % [kg/m3] Tetthet olje

D_in=0.5; %[m] indre diameter r�r
e_re=0.0015; % [mm] ruhet i r�r (litteraturverdi for PVC)
U_sw = 1; %[m/s] hastighet vann
U_so = 1; %[m/s] hastighet olje

mu_o=35*10^(-3); %[Pa*s]
mu_w=10*10^(-3); %[Pa*s]
Phi_100=0.765; % is used as proposed by S�ntvedt and Valle (1994) 


%% Inputs
%iml = intermediat layer / dispersion layer
eps_iml_w=0.3;
eps_iml_o=1-eps_iml_w;

%% IML fluid porperties
% Density 
rho_iml=eps_iml_o*rho_o+eps_iml_w*rho_w; %[kg/m3]
% Vicosty

% henter inn vikosistet for den sammenhengen fasen
if eps_iml_o >= eps_iml_w
    mu_c=mu_o;
    disp('Oil cont. iml flow')
else
    mu_c=mu_w;
    disp('Water cont. iml flow')
end

disp_frac=min(eps_iml_o,eps_iml_w);
mu_iml=mu_c*(1+((0.8415*disp_frac)/Phi_100)/(1-0.8415*disp_frac/Phi_100))^2.5;
disp(mu_iml)

% Liquid hights
h_o= 0.1 %[m]
h_w= 0.1  %[m]

%% Geometry
%Area
A_tot=pi*(D_in^2/4)
A_o=(D_in/2)^2*acos(1-(2*h_o)/D_in)-((D_in/2)-h_o)*sqrt(D_in*h_o-h_o^2)

A_w=(D_in/2)^2*acos(1-(2*h_w)/D_in)-((D_in/2)-h_w)*sqrt(D_in*h_w-h_w^2)

A_iml=A_tot-(A_o+A_w)

% angle of phase, form from center, in order to find permitter
ang_o=cent_angf(A_o,D_in,0,2*pi)
ang_w=cent_angf(A_w,D_in,0,2*pi)

%fluid permitter
S_w=ang_o*(D_in/2);
S_o=ang_w*(D_in/2);
S_iml=pi*D_in-(S_o+S_w);
S_o_iml=D_in*sin(ang_o/2);
S_w_iml=D_in*sin(ang_w/2);