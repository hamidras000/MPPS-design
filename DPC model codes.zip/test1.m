% Sigurd Harstad
% 7.5.2020
% Prosjektoppgave
% Testscript 1

close all
clear all
clc

a=0.1;
b=a*rand(1,100)+a/2;
disp(b)
c=mean(b)