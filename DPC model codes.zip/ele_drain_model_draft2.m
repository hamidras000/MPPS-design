% Sigurd Harstad
% 17.4.2020
% Posjekt
% Drainage curve model, draf 2,  Sigurd Harstad

close all
clear all
clc

%% Logical
TRUE=1;
FALSE=0;

%Goal 
% alfa_wc = int ( 0-D) alfa(y) * W (y) dy
%% Area of pipe
% needs a fuction of width of pipe W(y) to find
% inputs
D_in=1; %[m] % Inner diamter of pipe
y=linspace(0,D_in,1e4); % discretization the pipe into segments
width=zeros(1,length(y)); % empty array for width

A=zeros(1,length(y));% empty array for segment area, A=segment area
width=width_func(y,D_in); % call width function
%% Area of pipe using midpoint rule methode
for i=1:length(y)
    if i==1
        A(i)=(width(i))*(y(i)); % first entry
    else
    A(i)=((width(i)+width(i-1))/2)*(y(i)-y(i-1)); % midpoint value for area
    end
end
Ageo=(D_in^2/4)*pi; % Gemoetric determine area, in order to compare aprox.
Aitt=sum(A); % Total area of pipe, using aprox
error=abs(Ageo-Aitt); % compare gemetric and aprox
relerror=error/Aitt; % determine relativ error of aprox area of pipe

%% Water cut

%% Uniforme water cut
if (FALSE)
    % WC_in=input('Input Water cut into system [0-1]')
    WC_in=0.3;
    alfa_i=WC_in; % uniform water cut
    alfa=zeros(1,length(y));
    for i=1:length(y)
        alfa(i)=alfa_i;
    end   
end 

%% Straified flow uncontaminated phases
% alfa = 1 in lower part, alfa = 0 in upper part
if(FALSE)
    WC_in=0.9;
    alfa=step_alfa(y,WC_in,A);
end
%% Stratified flow contaminated phases
% cont_w = contaminated of water (oil in water)
% cont_o = contaminated of oil (water in oil)
% alfa = 1-cont_w in lower part, alfa = 0+cont_w in upper part
if(FALSE)
    WC_in=0.5;
    cont_o=0.2; % WiO
    cont_w=0.2; % OiW
    alfa=step_cont_alfa(y,WC_in,A,cont_o,cont_w);
end

%% Stratified flow contaminated phases random contamination
% cont_w = mean contaminated of water (oil in water)
% cont_o = mean contaminated of oil (water in oil)
% alfa = 1-cont_w in lower part, alfa = 0+cont_w in upper part
if(FALSE)
    WC_in=0.5;
    cont_o=0.1; % WiO
    cont_w=0.1; % OiW
    alfa=step_cont_rand_alfa(y,WC_in,A,cont_o,cont_w);
end

%% Lin transiton from water to oil
if(FALSE)
    WC_in=0.9;
    y_inter=0.4;
    alfa=lin_trans_alfa(y,WC_in,A,y_inter);
    
end
%% Lin transiton from water to oil w/ contamination
if(TRUE)
    WC_in=0.5;
    y_inter=0.4;
    cont_o=0.2; % WiO
    cont_w=0.2; % OiW
    alfa=lin_trans_alfa_cont(y,WC_in,A,y_inter,cont_o,cont_w);
    
end

%% Random water cut
if(FALSE)
    WC_in=0.5;
   alfa=rand(1,length(y));
end

%% Othe water cute
if(FALSE)
   % not in use
end

%% Water content
v_liquid=2; %[m/s]
%q = A* v
q_water_arr=zeros(1,length(y));
q_liq_arr=zeros(1,length(y));
for i=1:length(y)
    if i==1
        q_water_arr(i)=(width(i))*(y(i))*(alfa(i))*v_liquid;
        q_liq_arr(i)=(width(i))*(y(i))*v_liquid;
    else
    q_water_arr(i)=((width(i)+width(i-1))/2)*(y(i)-y(i-1))*((alfa(i)+alfa(i-1))/2)*v_liquid;
    q_liq_arr(i)=((width(i)+width(i-1))/2)*(y(i)-y(i-1))*v_liquid;
    end
end
%% Water drainage

cnt2=1;
h=0:0.01:D_in;
q_water_tapped=zeros(1,length(h));
q_water_total=zeros(1,length(h));
pst_q_tot_tapped=zeros(1,length(h));
wc_tapped_calc=zeros(1,length(h));

while h(cnt2)<D_in
    cnt=1;
    q_liq_tap_arr=zeros(1,length(y));
    q_water_tap_arr=zeros(1,length(y));
    while y(cnt)<h(cnt2)
        q_liq_tap_arr(cnt)=q_liq_arr(cnt);
        q_water_tap_arr(cnt)=q_water_arr(cnt);
        cnt=cnt+1;
    end
    q_water_tapped(cnt2)=sum(q_water_tap_arr);
    q_water_total(cnt2)=sum(q_water_arr);
    pst_q_tot_tapped(cnt2)=100*((q_water_tapped(cnt2))/q_water_total(cnt2));
    if (sum(q_liq_tap_arr))==0
        wc_tapped_calc(cnt2)=alfa(1)*100;
    else
    wc_tapped_calc(cnt2)=100*(sum(q_water_tap_arr))/(sum(q_liq_tap_arr));
    end
    cnt2=cnt2+1;
end

   if h(cnt2)==D_in % all liquid is drained
    q_water_tapped(cnt2)= Aitt*v_liquid*WC_in;
    q_water_total(cnt2)=q_water_tapped(cnt2);
    pst_q_tot_tapped(cnt2)=100*(q_water_tapped(cnt2))/(q_water_total(cnt2));
    wc_tapped_calc(cnt2)=100*WC_in;
end

%% Results

fprintf('Area of pipe from gemetri %.4f [m2]\n',Ageo) % print area of pipe geo
fprintf('Area of pipe from aprox %.4f [m2]\n',Aitt) % print area of pipe calc
fprintf('Relaive error in aprox and gemotri %.4E []\n',relerror) % print relative error of area
figure
plot(wc_tapped_calc,pst_q_tot_tapped,'-b')
axis([-5,110,-5,110])
xlabel('Water cut of tapped stream [%]')
ylabel('Water tapped of totalt water in stream [%]')
grid on
title('Drainage pot. plot')

temp2=y/D_in; % normilize postion y in pipe by the the diameter
figure
plot(alfa,temp2,'--r')
clear temap2
axis([-1,2,0,1])
xlabel('Water cut[]')
ylabel('Normalized position in pipe')
grid on
title('Water content at position')

WC_end_chech=sum(A.*alfa)/sum(A);
WC_error=abs(WC_in-WC_end_chech);
WC_rel=WC_error/WC_end_chech;
a=100*WC_in;
b=100*WC_end_chech;

fprintf('Water cut input %.4f [%%] \n',a) %print WC input
fprintf('Water cut calculatet %.4f [%%] \n',b) %print WC calc.
fprintf('Relaive error in Water cut calculated %.4E []\n',WC_rel) %print relative error of WC
clear a b
%% Export water cut curve results to Excel
% Store values generated in Excel
if(FALSE)
    t=clock;
    store1=[y(:),alfa(:)];
    xlswrite('C:\Users\sigur\Documents\Student\NTNU\Prosjekt\Resulteter\04_06_2020_model_results3.xls',t,'Ark1','A1:F1')
    xlswrite('C:\Users\sigur\Documents\Student\NTNU\Prosjekt\Resulteter\04_06_2020_model_results3.xls',WC_in,'Ark1','A2')
    xlswrite('C:\Users\sigur\Documents\Student\NTNU\Prosjekt\Resulteter\04_06_2020_model_results3.xls',store1,'Ark1','A3:B1002')
    clear store1
end
%% Export drainage curve results to Excel
% Store values generated in Excel
if(FALSE)
    t=clock;
    store1=[wc_tapped_calc(:),pst_q_tot_tapped(:)];
    xlswrite('C:\Users\sigur\Documents\Student\NTNU\Prosjekt\Resulteter\06_06_2020_model_results3.xls',t,'Ark4','A1:F1')
    xlswrite('C:\Users\sigur\Documents\Student\NTNU\Prosjekt\Resulteter\06_06_2020_model_results3.xls',WC_in,'Ark4','A2')
    xlswrite('C:\Users\sigur\Documents\Student\NTNU\Prosjekt\Resulteter\06_06_2020_model_results3.xls',store1,'Ark4','A3:B103')
    
end
%% Error seacht

