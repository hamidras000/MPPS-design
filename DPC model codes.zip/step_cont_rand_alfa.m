function[alfa]=step_cont_rand_alfa(y,WC_tot,A,cont_o,cont_w)
% Input: y, postion from in [m] lower edgt of pipe, y=0.
% diamter of pipe [m]
% WC_tot totalt water cut
% A, array of Area 
% Output. Water content alfa(y) as a function of position y, distance from
% y=0, lower pipe
%n=length(y);
d=y(end);
if y>d
    disp('postiton outside of pipe, y larger then d, diameter of pipe')
    return
end
error=1;

delta=10e-6;
a=y(1);
b=y(end);
h=rand;
f=@(h) WC_tot-(sum(A.*(max((1-heaviside(y-h)-cont_w),cont_o))))./sum(A);

[c,err,yc]=bisect(f,a,b,delta);

n=length(y);
cont_w2=cont_w*rand(1,n)+(cont_w/2);
cont_o2=cont_o*rand(1,n)+(cont_o/2);
alfa=max((1-heaviside(y-c)-cont_w2),cont_o2);

return