% Sigurd Harstad
% 4.4.2020
% Posjekt
% Homogeneous dispersed flow model, By Heiner Schumann

close all
clear all
clc

%% Logisk forenkling
TRUE=1;
FALSE=0;

%% Konstanter
rho_w = 1000; %[kg/m3] Tetthet vann
rho_o = 600; % [kg/m3] Tetthet olje

D_in=0.1; %[m] indre diameter r�r
e_re=0.0015; % [mm] ruhet i r�r (litteraturverdi for PVC)
U_sw = 1; %[m/s] hastighet vann
U_so = 1; %[m/s] hastighet olje

mu_o=35*10^(-3); %[Pa*s]
mu_w=10*10^(-3); %[Pa*s]
Phi_100=0.765; % is used as proposed by S�ntvedt and Valle (1994) 
%% Inputs
eps_w=0.3;  % [] Fraksjon vann

%% Test for viskositetrelasjon

% Test for viskositet som funksjon av vanninnhold, "uncomet" for � teste
% x=linspace(0,1,10000);
% i=1;
% clear eps_w
% for i=1:length(x)
% eps_w=x(i); % [] Fraksjon vann
% eps_o= 1-eps_w; % Fraksjon olje
% rho_mix=eps_w*rho_w+eps_o*rho_o; % tetthet av blandingen


eps_o= 1-eps_w; % Fraksjon olje
rho_mix=eps_w*rho_w+eps_o*rho_o; % tetthet av blandingen


%% Mixture viscosity

% henter inn vikosistet for den sammenhengen fasen
if eps_o >= eps_w
    mu_c=mu_o;
    disp('Oil cont. flow')
else
    mu_c=mu_w;
    disp('Water cont. flow')
end

disp_frac=min(eps_o,eps_w);

mu_mix(1)=mu_c*(1+((0.8415*disp_frac)/Phi_100)/(1-0.8415*disp_frac/Phi_100))^2.5;

U_mix= U_so+U_sw; 
%% Reynolds mix
re_mix=(rho_mix*U_mix*D_in)/mu_mix;

% re_mix=linspace(100,10e8,1000);
f_mix=zeros(1,length(re_mix));
%for i=1:length(re_mix)
    
%% Friksjons faktor
% Churchill equation valid for both turbulent and laminar flow, 
% predicting a smooth transition, is applied to solve directly for the
% friction factor (Churchill, 1977)

Tetha_1=(-2.457*log((7/re_mix(1))^0.9+0.27*(e_re/D_in)))^16;
Tetha_2= (37530/re_mix(1))^16;

f_mix(1)=8*((8/re_mix(1))^12+1/((Tetha_1+Tetha_2)^1.5))^(1/12);


%% Display fluid values
fprintf('Dispered fraction is %.2f []\n',disp_frac)

fprintf('Viscosity of coun. phase is %.4f [Pa*s]\n',mu_c)

fprintf('Viscosity of mixed phase is %.4f [Pa*s]\n',mu_mix)

fprintf('Density of mixed phase is %.2f [kg/m3]\n',rho_mix)

%% Pressure loss calc. 1D
% -(dp/dz) = f_mix * rho_mix * Umix^2 / 2D
L_end=1000; %[m]
L_start=0; %[m]
P_start=1*10^5; %[Pa]
n=1e3; %[itterasjoner]

x_lat=linspace(L_start,L_end,n);
P=zeros(1,length(x_lat));
for j=1:length(x_lat)
    if j==1
        P(j)=P_start;
    else
        P(j)=P(j-1)-((f_mix*rho_mix*(U_mix^2)) / 2*D_in)*(x_lat(j)-x_lat(j-1));
    end
end
figure
plot(x_lat,P)
grid on