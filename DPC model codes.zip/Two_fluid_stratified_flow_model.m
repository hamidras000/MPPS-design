% Sigurd Harstad
% 12.4.2020
% Posjekt
% Two-fluid stratified flow model , By Heiner Schumann

close all
clear all
clc

%% Konstanter
rho_w = 1000; %[kg/m3] Tetthet vann
rho_o = 600; % [kg/m3] Tetthet olje

D_in=0.1; %[m] indre diameter r�r
e_re=0.0015; %[mm] ruhet i r�r (litteraturverdi for PVC)
U_sw = 1; %[m/s] hastighet vann
U_so = 1; %[m/s] hastighet olje

mu_o=35*10^(-3); %[Pa*s]
mu_w=10*10^(-3); %[Pa*s]
Phi_100=0.765; % is used as proposed by S�ntvedt and Valle (1994) 

%% Inputs
eps_w=0.4;  % [] Fraksjon vann
eps_o= 1-eps_w; % Fraksjon olje

U_o=U_so/eps_o;
U_w=U_sw/eps_w;

%% Friksjons faktor
% Churchill equation valid for both turbulent and laminar flow, 
% predicting a smooth transition, is applied to solve directly for the
% friction factor (Churchill, 1977)

%% Oil phase prop
re_o=(rho_o*U_o*D_in)/mu_o;

Tetha_1=(-2.457*log((7/re_o)^0.9+0.27*(e_re/D_in)))^16;
Tetha_2= (37530/re_o)^16;

disp(Tetha_1)
disp(Tetha_2)

%pause
f_o=8*(((8/re_o))^12+1/((Tetha_1+Tetha_2)^1.5)^(1/12));

%% Water phase prop
re_w=(rho_w*U_w*D_in)/mu_w;

Tetha_1=(-2.457*log((7/re_w)^0.9+0.27*(e_re/D_in)))^16;
Tetha_2=(37530/re_w)^16;

%disp(Tetha_1)
%disp(Tetha_2)

f_w=8*(((8/re_w))^12+1/((Tetha_1+Tetha_2)^1.5)^(1/12));

%disp(f_o)
%disp(f_w)
%% Pressure losse 1D

So=0.3;
Sw=1-So;
% - (dp/dz)_2fluid = So/S (dp/dz)_o +Sw/S (dp/dz)_w 

L_end=1000; %[m]
L_start=0; %[m]
P_start=10*10^5; %[Pa]
n=1e3; %[itterasjoner]
x_lat=linspace(L_start,L_end,n);

P=zeros(1,length(x_lat));
for j=1:length(x_lat)
    if j==1
        P(j)=P_start;
    else
        P(j)=P(j-1)-(So*(f_o*rho_o*(U_o^2)) / (2*D_in)*(x_lat(j)-x_lat(j-1))+...
(Sw*(f_w*rho_w*(U_w^2)) / (2*D_in)*(x_lat(j)-x_lat(j-1))));
    end
end

%% Display fluid values

fprintf('Water fraction is %.2f []\n',eps_w)
fprintf('Oil fraction is %.2f []\n',eps_o)

fprintf('Viscosity of water phase is %.4f [Pa*s]\n',mu_w)
fprintf('Viscosity of oil phase is %.4f [Pa*s]\n',mu_o)

fprintf('Density of water phase is %.2f [kg/m3]\n',rho_w)
fprintf('Density of oil phase is %.2f [kg/m3]\n',rho_o)
fprintf('Friction factor of water phase is %.4f [kg/m3]\n',f_w)
fprintf('Friction factor of oil phase is %.4f [kg/m3]\n',f_o)

%% Plotting
figure
plot(x_lat,P)
grid on

