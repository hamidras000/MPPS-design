function[alfa]=lin_alfa(y,d,WC_tot,n)
% Input: y, postion from in [m] lower edgt of pipe, y=0.
% diamter of pipe [m]
% WC_tot totalt water cut, sum of all alfa must be equal to WC_in
% n slicing of pipe, given from griding of from area
% Output. Water content alfa(y) as a function of position y, distance from
% y=0, lower pipe

if y>d
    disp('postiton outside of pipe, y larger then d, diameter of pipe')
    return
end

% find a h alfa=0 such that WC_pipe = WC_tot 
f=@x WC_tot- 
holder1=linspace(0,d,n)

holder2=linspace(0,1,m)

return