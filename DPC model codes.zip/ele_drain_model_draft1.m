% Sigurd Harstad
% 17.4.2020
% Posjekt
% Elimental drain prefromance, draf 1,  Sigurd Harstad

close all
clear all
clc

%Goal 
% alfa_wc = int ( 0-D) alfa(y) * W (y) dy
%% Area of pipe
% needs a fuction of width of pipe W(y) to find
% inputs
D_in=1; %[m]
r=D_in/2; %[m]
y=linspace(0,D_in,1e5);
width=zeros(1,length(y));
A=zeros(1,length(y));
for i=2:length(y)
if y(i) <r
    d=r-y(i);
    width(i)=2*r*sin(acos(d/r));
    A(i)=((width(i)+width(i-1))/2)*(y(i)-y(i-1));
    %disp('under midline')
elseif y(i)==r
    width(i)=2*r;
    A(i)=((width(i)+width(i-1))/2)*(y(i)-y(i-1));
    %disp('midline')
else
   d=y(i)-r;
   width(i)=2*r*sin(acos(d/r));
   A(i)=((width(i)+width(i-1))/2)*(y(i)-y(i-1));
   %disp('over midline')
end
end
%disp(width)
figure
plot(y,width)
figure
plot(y,A)
Ageo=(D_in^2/4)*pi;
Aicr=sum(A);
error=abs(Ageo-Aicr);
disp(error)