function (A,D,a,b)=alfa_i
% Sigurd Harstad
% 16.4.2020
% Posjekt
% Inntertve solve for angle

x=linspace(a,b,1e6)
A_int=zeros(1,length(x))
A_int=(D^2/8).*(x-sind(x))

Aerror= abs(A-A_int)
[m]=min(Aerror)
alfa_i=x(m(2))

end