function[W]=width_func(y,d)
%input y = hight from y=0, lowest point of pipe
% d= diamter of pipe in [m]
% output, width of a pipe, given in [m]
r=d/2;
if y>d
    disp('postiton outside of pipe, y larger then d, diameter of pipe')
    return
end
if y<r
    d=r-y;
    W=2*r*sin(acos(d/r));
elseif y==r
    W=2*r;
else
   d=y-r;
   W=2*r*sin(acos(d/r));
end
return
