function[alfa]=step_alfa(y,WC_tot,A)
% Input: y, postion from in [m] lower edgt of pipe, y=0.
% diamter of pipe [m]
% WC_tot totalt water cut
% A, array of Area 
% Output. Water content alfa(y) as a function of position y, distance from
% y=0, lower pipe
%n=length(y);
d=y(end);
if y>d
    disp('postiton outside of pipe, y larger then d, diameter of pipe')
    return
end
error=1;

delta=10e-5;
a=y(1);
b=y(end);
h=rand;
f=@(h) WC_tot-(sum(A.*(1-heaviside(y-h)))./sum(A));

[c,err,yc]=bisect(f,a,b,delta);

alfa=(1-heaviside(y-c));
return