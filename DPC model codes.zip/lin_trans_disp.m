function[sub_alfa]=lin_trans_disp(y,h,d_inter)
% y = position in pipe
% h = positon of "interface" the point where the domintans fluid switsh
% d_inter = width of trasistion zone over interface


n=length(y);
intermid=zeros(1,n);
for i=1:n
if (y(i)>h-d_inter/2 && y(i)<h+d_inter/2)
  intermid(i)=1;
end
m=sum(intermid);
end
sub_alfa=zeros(1,n);

for i=1:n
    if i==1
        sub_alfa=1;
    else
        if (y(i)<h-d_inter/2)
            sub_alfa(i)=1;
        elseif (y(i)>h+d_inter/2)
            sub_alfa(i)=0;
        else
            sub_alfa(i)=sub_alfa(i-1)-1/m;
        end
    end

end
return